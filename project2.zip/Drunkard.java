/*
*
* @author: Irene Nam
* @date 2/19/2018
*
* This class randomly selects a direction
* at an intersection and moves on to the next
* Prints out final position and distance. 
*
*
*/

public class Drunkard
{
	//declare instance variables
	private int initialAvenue;
	private int initialStreet;
	private int movedAvenue;
	private int movedStreet;
	//just for direction purpose, these integers will be
	//matched with the random singleStep integer to move
	//the drunkard
	private int north = 1;
	private int east = 2;
	private int south = 3;
	private int west = 4;
	
	//initialize the instance variables in this method
	public Drunkard(int avenue, int street)
	{
		initialAvenue = avenue;
		initialStreet = street;
		movedAvenue = 0;
		movedStreet = 0;
	}
	
	//step method will move the drunkard to the next randomly
	//chosen intersection by getting random integers from 1-4
	//which corresponds to different directions and moves the
	//drunkard accordingly.
	public void step(){
		//Math.random method will receive any random float between
		//0 and (not including) 1, so multiplying it by 4 and 
		//adding 1 will give any random float between 1 and 
		//(not including) 5, which will return random integers 1,2,3,4.
		int singleStep = (int) (Math.random()*4 + 1);

		if (singleStep == north){
			movedStreet = movedStreet + 1;
		}
		else if (singleStep == east){
			movedAvenue = movedAvenue + 1;
		}
		else if (singleStep == south){
			movedStreet = movedStreet - 1;
		}
		else if (singleStep == west){
			movedAvenue = movedAvenue - 1;
		}
	}
	
	//fastForward method will take in the integer number of
	//steps and then repeat the step method by using the for
	//loop and looping it for that number of times.
	public void fastForward(int steps)
	{
		for (int i = 0; i < steps; i++)
		{
			step();
		}
	}
	
	//getLocation method will figure out the final location
	//by adding the initial and moved variables for each x and y.
	//It will then return a string that prints the final 
	//avenue and street location.
	public String getLocation()
	{
		int streetLocation = initialStreet + movedStreet;
		int avenueLocation = initialAvenue + movedAvenue;
		String location =  "Avenue: " + avenueLocation + ", Street: " + streetLocation;
		return location;
	}
	
	//howFar method will calculate the manhattan distance of the
	//final distance from the initial by using the Math.abs method
	//which returns the absolute value of the number.
	public int howFar()
	{
		int distance = Math.abs(movedAvenue) + Math.abs(movedStreet);
		return distance;
	}
}