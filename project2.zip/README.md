# COMS W1004 

## Spring 2018

## Programming Project 2
### (50 points)
### Due February 19, 11:59PM  


----------------------------------------------------------------  

  
    



**Problem 1** (20 points): Do Programming Project P5.8 in Big Java Early Objects 6th Edition (P5.5 in the 5th Edition). I have provided templates for a class Year and a test class LeapYearTester on Codio. You must use the template and you must not alter the test class.


**Problem 2** (30 points): The Drunkard's (Random) Walk. Imagine you live on an infinite grid of streets where locations are represented as integer pairs (avenue,street). Negative numbers are okay in this example. Now consider a drunkard that randomly picks one of four directions at an intersection and then stumbles to the next intersection doing the same and so on. Write a class Drunkard to simulate this behavior given the drunkard's initial position. Your Drunkard class should have as instance variables the drunkard's current avenue (x location) and current street (y location). Your class should have a method called step( ) that moves the drunkard to the next randomly chosen adjacent intersection. Your class should have another method called fastForward(int steps) that takes an integer as a parameter (call it steps) and moves the drunkard steps intersections from his current location. Your class should have a method getLocation( ) that returns a String indicating the drunkard's current location. Finally your class should have a method called howFar( ) that reports the drunkards distance in blocks from where he started calculated using the [Manhattan distance metric](http://xlinux.nist.gov/dads//HTML/manhattanDistance.html). 

You will find a test class called DrunkardTester on Codio. *Your Drunkard class must work with the test class provided without modification.* You must NOT alter the test class.

### Submitting your work (READ THIS!):

Please submit your program source files on Canvas. You must export them from codio, compress them into a single zip file, and submit them on Canvas. The compressed file you submit should be called [your UNI]_pp2.zip so for example my submission would be called ac1076_pp2.zip



### Grading
Each question in the Programming portion of your assignment will be graded as follows:

30% if it compiles  
30% if it runs properly (expected output for given input, etc.)  
20% for style (formatting of code, variable names, comments, etc. Use the style guide posted on Coursworks!)  
20% for design (efficiency, good use of classes including division of labor into methods, etc.)  

Please make sure your program at least compiles before you submit it! There will be no partial credit for a program that "almost" compiles.
