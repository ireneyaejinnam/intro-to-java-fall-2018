/*
*
* @author: Irene Nam
* @date 2/19/2018
*
* This class represents a calendar year.
*
* It contains a method that determines if
* the year is a leap year.
*
*/


public class Year{
    
	// declare your instance variables here
	private int year;

    // write your constructor here

    public Year(int y){
		//initialize instance variables
		year = y;
    }


    public boolean isLeapYear(){
        // If statement tests for the leap year requirements
        // Returns true if leap year, if not, returns false 
        if (year%4==0 && (year%400==0 || year%100!=0)){
			return true;
		}
		else{
			return false;
		}
    }

}    

