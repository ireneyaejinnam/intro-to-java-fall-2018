//*************************************
//
//  WordListsTester.java
//
//  Class to aid with Scrabble
//  Checks exceptions and tests method
//  Programming Project 5, COMS W1004
//
//
//  Your Name: Irene Nam
//  Your Uni: yn2334
//**************************************


import java.util.ArrayList;
import java.io.*;


public class WordListsTester{
	
	//try/catch FileNotFoundException thrown from the WordLists class
	public static void main (String[] args){
		
		WordLists words;
		
		try{
			words = new WordLists("dictionary.txt");
			lengthN_test(words);
			startsWith_test(words);
			containsLetter_test(words);
			multiLetter_test(words);
		}
		
		catch (FileNotFoundException f){
			System.out.println("Please enter a valid file name. Try again.");
			System.out.println(f);
		}
	}
	
	//tests the lengthN method and creates the text file for it
	public static void lengthN_test(WordLists testArrayList) throws 
	FileNotFoundException{
		
		ArrayList<String> test = testArrayList.lengthN(10);

		PrintWriter finalFile = new PrintWriter("lengthN.txt");
		
		for (String word : test){
			finalFile.println(word);
		}

		finalFile.close();

	}

	//tests the startsWith method and creates the text file for it
	public static void startsWith_test(WordLists testArrayList) throws 
	FileNotFoundException{
		
		ArrayList<String> test = testArrayList.startsWith('d', 4);

		PrintWriter finalFile = new PrintWriter("startsWith.txt");
		for (String word : test){
			finalFile.println(word);
		}

		finalFile.close();
	}
	
	//tests the containsLetter method and creates the text file for it
	public static void containsLetter_test(WordLists testArrayList) throws 
	FileNotFoundException{

		ArrayList<String> test = testArrayList.containsLetter('h', 5);

		PrintWriter finalFile = new PrintWriter("containsLetter.txt");
		for (String word : test){
			finalFile.println(word);
		}

		finalFile.close();
		
	}
	
	//tests the multiLetter method and creates the text file for it
	public static void multiLetter_test(WordLists testArrayList) throws 
	FileNotFoundException{
		
		ArrayList<String> test = testArrayList.multiLetter('a', 4);

		PrintWriter finalFile = new PrintWriter("multiLetter.txt");
		for (String word : test){
			finalFile.println(word);
		}

		finalFile.close();
		
	}
}