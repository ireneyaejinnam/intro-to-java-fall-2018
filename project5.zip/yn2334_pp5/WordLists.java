//*************************************
//
//  WordLists.java
//
//  Class to aid with Scrabble
//  Checks words for w specific conditions
//  Programming Project 5, COMS W1004
//
//
//  Your Name: Irene Nam
//  Your Uni: yn2334
//**************************************

import java.util.ArrayList;
import java.io.*;
import java.util.Scanner;


public class WordLists{

	//Instance variable ArrayList to hold the dictionary words
	ArrayList <String> wordList;
	
	//Constructor that takes in the fileName as a parameter
	//puts all the words in the ArrayList
    public WordLists(String fileName) throws FileNotFoundException{
		
		wordList = new ArrayList <String> ();
		File someFile = new File(fileName);
		Scanner input = new Scanner(someFile);
		
		while (input.hasNext()){			
				wordList.add(input.nextLine());	
		}
		
		input.close();
		
    }


	//Finds all words of length n and returns an ArrayList of 
	//words that are of length n
    public ArrayList<String> lengthN(int n) {
        
		if (n < 0){
			throw new IllegalArgumentException("n can't be less than 0.");
		}
		
        ArrayList <String> nLength = new ArrayList <String> ();
		
		for (int i = 0; i < wordList.size(); i++){
			if (wordList.get(i).length() == n){
				nLength.add(wordList.get(i));
			}
		}
		
		return nLength;
		
    }


	//Finds all words of length n and starts with a specific letter,
	//returns an ArrayList of these words
    public ArrayList<String> startsWith(char firstLetter, int n) {

		if (n < 0){
			throw new IllegalArgumentException("n can't be less than 0.");
		}
		
		if (!Character.isLetter(firstLetter)){	
			throw new IllegalArgumentException("input should be a letter.");	
		}
		
        ArrayList <String> sameLengthStart = new ArrayList <String> ();
		
		for (int i = 0; i < wordList.size(); i++){
			if (wordList.get(i).length() == n && wordList.get(i).charAt(0) 
				== firstLetter){
				sameLengthStart.add(wordList.get(i));
			}
		}
		
		return sameLengthStart;

    }


	//Finds all words of length n and contains a specific letter,
	//returns an ArrayList of these words
    public ArrayList<String> containsLetter(char included, int n) {

		if (n < 0){
			throw new IllegalArgumentException("n can't be less than 0.");
		}
		
		if (!Character.isLetter(included)){
			throw new IllegalArgumentException("input should be a letter.");
		}
		
		ArrayList <String> letterContained = new ArrayList <String> ();
		
		for (int i = 0; i < wordList.size(); i++){
			if (wordList.get(i).length() == n && wordList.get(i).indexOf(
				included) > 0 && wordList.get(i).charAt(0) != included) {
				letterContained.add(wordList.get(i));
			}
		}
		
		return letterContained;

    }

 
	//Finds all words that contains m number of a specific letter,
	//returns an ArrayList of these words
    public ArrayList<String> multiLetter(char included, int m) {

		if (m < 0){
			throw new IllegalArgumentException("n can't be less than 0.");
		}
		
		if (!Character.isLetter(included)){
			throw new IllegalArgumentException("input should be a letter.");
		}
		
        ArrayList <String> multipleLetters = new ArrayList <String>();
		
		for (int i = 0; i < wordList.size(); i++){
			String word = wordList.get(i);
			int count = 0;
			
			for (int j = 0; j < word.length(); j++){
				if (word.charAt(j) == included){
					count ++;
				}
			}
			
			if (count >= m){
				multipleLetters.add(word);
			}
		}

		return multipleLetters;
		
    }

}