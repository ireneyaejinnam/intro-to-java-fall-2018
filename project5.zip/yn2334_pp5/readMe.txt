----------------------------------------------------------------------
readMe.txt
Programming Project 5

Name: Irene Nam
UNI: yn2334

----------------------------------------------------------------------
WordLists.java


In this class, an ArrayList is created to hold the words from dictionary.txt. Then, a constructor takes in the filename and the parameter, adding the words to the ArrayList called wordList. 

Then, four methods are made to test the conditions given in the instructions. 
The lengthN method finds all words of length n and returns and ArrayList of words that meet the standards. It will also throw new illegal argument exception if the n is less than zero.
The startsWith method finds all words of length n and starts with a specific letter, then returns and ArrayList of words that meet the standards. It will also throw new illegal argument exception if the n is less than zero or the character input is not a single letter.
The containsLetter method finds all words of length n and includes a specific letter, then returns and ArrayList of words that meet the standards. It will also throw new illegal argument exception if the n is less than zero or the character input is not a single letter.
The multiLetter method finds all words that contains m number of a specific letter, then returns and ArrayList of words that meet the standards. It will also throw new illegal argument exception if the n is less than zero or the character input is not a single letter.

----------------------------------------------------------------------
WordListsTester.java


In this class, the main method checks for the FileNotFoundException as well as tests the four conditional methods from the other class and creates a txt file for the words that meet the conditions in the method.

The main method uses try/catch to check if the parameter in the WordLists is valid. If not, it will catch the FileNotFoundException and terminate the program.

Then, four methods are made to test the four methods (conditions) in the WordLists.java.
The lengthN_test method checks the lengthN method in the other class, creates a txt file by using PrintWriter, and prints out the words that meet the method's criteria in the file.
The startsWith_test method checks the startsWith method in the other class, creates a txt file by using PrintWriter, and prints out the words that meet the method's criteria in the file.
The containsLetter_test method checks the containsLetter method in the other class, creates a txt file by using PrintWriter, and prints out the words that meet the method's criteria in the file.
The multiLetter_test method checks the multiLetter method in the other class, creates a txt file by using PrintWriter, and prints out the words that meet the method's criteria in the file.
