/*
 * This program converts a number of hours, days, and years into minutes.
 * 
 * @author: Irene Nam
 * @date: 1/30/2018
 */

import java.util.Scanner;

public class Minutes{
    
    public static void main(String[] args){
        
		//Receive number of years from user.
        Scanner time = new Scanner(System.in);
        System.out.println("Please enter the number of years: ");
        int years;
        years = time.nextInt();
        
		//Receive number of days from user.
        System.out.println("Please enter the number of days: ");
        int days;
        days = time.nextInt();
        
		//Receive number of hours from user.
        System.out.println("Please enter the number of hours: ");
        int hours;
        hours = time.nextInt();
        
		//convert time to minutes
        int minutes = 60*hours + 24*60*days + 365*24*60*years;
        
		//print out the number of minutes
        System.out.println(years + " years, " + days + " days, and " + hours + " hours is " + minutes + " minutes.");
        
    }
}
 
