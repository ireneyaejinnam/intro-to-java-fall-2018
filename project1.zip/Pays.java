/**
 * This program determines the correct article to use for different
 * countries.
 * 
 * @author: Irene Nam
 * @date: 2/2/2018
 */

import java.util.Scanner;

public class Pays{

    public static void main(String[] args){
		
		//Receive name of the country from user.
        Scanner country = new Scanner(System.in);
        System.out.print("Please enter the name of the country: ");
        String countryName = country.nextLine();
        //length of country name = n
		int n = countryName.length();
        //Set all booleans false to begin with, so if it fulfills the condition it will turn true to fit the if statements at the end.
		boolean feminine = false;
        boolean startVowel = false;
        boolean pluralName = false;
        
        
        //Check for feminine names; apply exception for several names
        if (countryName.charAt(n-1)=='e'){
            if (countryName.equals("Belize") || 
                countryName.equals("Cambodge") ||
                countryName.equals("Mexique") ||
                countryName.equals("Mozambique") ||
                countryName.equals("Zaïre") ||
                countryName.equals("Zimbabwe")){
                    feminine = false;
            }
            else{
                feminine = true;
            }
        }
        
		//Check for double names
        else if(countryName.equals("Etats-Unis") ||
               countryName.equals("Pays-Bas")){
                pluralName = true;
        }
        
		//Check for names that start with a vowel
        else if(countryName.charAt(0)=='A' ||
               countryName.charAt(0)=='E' ||
               countryName.charAt(0)=='I' ||
               countryName.charAt(0)=='O' ||
               countryName.charAt(0)=='U' ||
               countryName.charAt(0)=='a' ||
               countryName.charAt(0)=='e' ||
               countryName.charAt(0)=='i' ||
               countryName.charAt(0)=='o' ||
               countryName.charAt(0)=='u'){
			startVowel = true;
            }
            
        //Print the name with the correct prefixes   
        if (pluralName == true){
            countryName = "les " + countryName;
        }
        else if(startVowel == true){
            countryName = "l'" + countryName;
        }
        else if(feminine == true){
            countryName = "la " + countryName;
        }
        else{
            countryName = "le " + countryName;
        }
        
        System.out.println(countryName);
    }
}