/**
 * This program determines how to provide change given the amount received
 * and the amount due.
 * 
 * @author: Irene Nam
 * @date: 1/30/2018
 */

import java.util.Scanner;

public class Change{
  
    public static void main(String[] args){
		
		//Receive amount due from user.
        Scanner money = new Scanner(System.in);
        System.out.println("Please enter the amount due: ");
        int amountDue;
        amountDue = money.nextInt();
        
		//Receive amount the user paid.
        System.out.println("Please enter the amount paid: ");
        int amountPaid;
        amountPaid = money.nextInt();
        
		//Calculate the change.
        int returnChange = amountPaid - amountDue;
        
		//Divide up the change into different kinds of money.
        int dollar = returnChange/100;
        returnChange = returnChange%100;
            
        int quarter = returnChange/25;
        returnChange = returnChange%25;
        
        int dime = returnChange/10;
        returnChange = returnChange%10;
        
        int nickel = returnChange/5;
        returnChange = returnChange%5;
        
        int penny = returnChange;
        
        //Print out the change.
        System.out.println("Change returned is shown below: ");
        System.out.println("Dollars: " + dollar);
        System.out.println("Quarters: " + quarter);
        System.out.println("Dimes: " + dime);
        System.out.println("Nickels: " + nickel);
        System.out.println("Pennies: " + penny);
    }

}	