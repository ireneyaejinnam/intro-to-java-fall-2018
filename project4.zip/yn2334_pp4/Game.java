//
// @Name: Irene Nam
// @UNI: yn2334
// 
// This class runs the game of poker.
// 
// 

import java.util.ArrayList;
import java.util.Scanner;

public class Game {
	
	//player instance variable
	private Player p;
	//deck instance variable
	private Deck cards;
	//String Array for suits
	private String[] suits = {"c", "d", "h", "s"};
	//String Array for ranks
	private String[] ranks = {"1", "2", "3", "4", "5", "6", "7",
							  "8", "9", "10", "11", "12", "13"};
	//boolean to check if testHand constructor is being used
	private boolean handTest = false;
	
	
	public Game(String[] testHand){
		
		// This constructor is to help test your code
		// use the contents of testHand to
		// make a hand for the player
		// use the following encoding for cards
		// c = clubs
		// d = diamonds
		// h = hearts
		// s = spades
		// 1-13 correspond to ace - king
		// example: s1 = ace of spades
		// example: testhand = {s1, s13, s12, s11, s10} = royal flush
		
		
		p = new Player();
		cards = new Deck();
		handTest = true;
		int suit = 0;
		String suitString = "";
		int rank = 0;
		String rankString = "";
		
		//divide up the suit and rank for card
		//add the plugged in card to the decks
		for (int i = 0; i < 5; i++){
			String singleCard = testHand[i];
			
			if(singleCard.length() == 2){
				suitString = singleCard.substring(0,1);
				rankString = singleCard.substring(1,2);
			}
			else if(singleCard.length() > 2){
				suitString = singleCard.substring(0,1);
				rankString = singleCard.substring(1,3);
			}
			
			for (int j = 0; j < 4; j++){
				if (suitString.equals(suits[j])){
					suit = j + 1;
				}
			}
			
			for (int k = 0; k < 13; k++){
				if (rankString.equals(ranks[k])){
					rank = Integer.parseInt(ranks[k]);
				}
			}
			
			Card newCard = new Card(suit, rank);
			p.addCard(newCard);
		}
		
	}
	
	
	//play a normal game by using a constructor with no argument.
	public Game(){
		p = new Player();
		cards = new Deck();
		p.intialBankroll(20);
	}
	
	//method that actually has all the functions of the game
	public void play(){
		//if using the testHand constructor, receive the cards
		//from the written list instead of receiving from deck.
		if (handTest == true){
			System.out.println(checkHand(p.getHand()));
		}
		
		//if not using the testHand constructor
		else{
			//player in game
			boolean in = true;
			
			//while loop to continue the game
			while (p.getBankroll() > 0 && in){
				Scanner scan = new Scanner(System.in);
				//show total balance using getBankroll method in Player class
				System.out.println("Total Balance: " + p.getBankroll());
				
				//check if token number is valid.
				boolean tokenChoice = true;
				while(tokenChoice){	
				System.out.println("How many tokens to bet? Choose between 1-5.");
					double tokenNum = scan.nextDouble();
					//if invalid token number, ask for a valid one
					if(tokenNum < 1 || tokenNum > 5 || tokenNum > p.getBankroll()){
						System.out.println("Enter a valid number of tokens.");
					}
					else{
						//if valid token number, stop asking for the token number
						//go through the bets method to calculate new balance
						//after the new bet.
						p.bets(tokenNum);
						p.getBets();
						tokenChoice = false;
					}
				}
				
				//print current total balance
				System.out.println("Your total Balance: " + p.getBankroll());
				
				//shuffle the card
				cards.shuffle();
				//reset the top card index after every play
				//so the cards never run out.
				cards.resetTop();
				
				//print out the cards in hand
				System.out.println("Cards in hand: ");
				for (int i = 0; i < 5; i++){
					Card oneCard = cards.deal();
					p.addCard(oneCard);
					System.out.println(oneCard.toString());
				}
				
				//let the player choose cards to switch
				System.out.println("Write the index of the card(s) you" +
								   " want to remove. (If first card, type 1."
								   + " If second and fourth card, type 24.)" +
								   "If you don't want to remove anything, " +
								   "type none.");
				
				//receive the player choice
				Scanner switchHand = new Scanner(System.in);
				String switchIn = switchHand.next();
				int c = 0;
				int switchLength = switchIn.length();
				
				//unless they do not want to switch anything,
				if(switchIn.equals("none") != true){
					//switch the cards at given index, leaving the
					//cards that the player wants to leave.
					for (int i = 0; i < switchLength; i++){
						Character oneSwitch = switchIn.charAt(i);
						int a = Character.getNumericValue(oneSwitch);
						Card newCard = cards.deal();
						p.replaceCard(a, newCard);
					}
					//display the new cards after switching
					System.out.println("New cards in hand: ");
					for (int k = 0; k < 5; k++){
						System.out.println(p.getHand().get(k));
					}
				}
				
				//score the hand by calculating the payout
				//and print out the new current balance
				System.out.println("Your hand is scored as: ");
				System.out.println(checkHand(p.getHand()));
				System.out.println("New current balance: " + p.getBankroll());
				
				//ask if the player wants to play again
				System.out.println("Would you like to play again?" + 
								   " (type in yes/no).");
				Scanner play = new Scanner(System.in);
				String playAgain = play.next();
				
				//if yes, continue the play
				if (playAgain.equals("yes")){
					//remove all the cards in the deck if the player
					//wants to play again
					for (int j = 0; j < 5; j++){
						p.removeCard(p.getHand().get(0));
					}
					continue;
				}
				
				//if no, stop the play
				else if (playAgain.equals("no")){
					in = false;
				}
					
			}
			
			//if player wants to be in but out of tokens,
			//the game automatically stops
			if(in) {
				System.out.println("No more tokens. Game Over.");
			}
			//if player ends the game, print out a different message
			else {
				System.out.println("Your balance is: " + p.getBankroll()
								   + ". Game Over.");
			}
			
		}
	}
	
	//take an ArrayList of cards as inputs
	//and determines what evaluates to and returns
	//it as a String.
	public String checkHand(ArrayList<Card> hand){
		//sort the hands
		p.sorting();
		
		//test it from the one that has has the
		//biggest payout
		if(royalFlush(hand)){
			p.winnings(250);
			return "Royal Flush!";
		}
		
		else if(straightFlush(hand)){
			p.winnings(50);
			return "Straight Flush!";
		}
		
		else if(fourOfKind(hand)){
			p.winnings(25);
			return "Four of a Kind!";
		}
		
		else if(fullHouse(hand)){
			p.winnings(6);
			return "Full House!";
		}
		
		else if(flush(hand)){
			p.winnings(5);
			return "Flush!";
		}
		
		else if(straight(hand)){
			p.winnings(4);
			return "Straight!";
		}
		
		else if(threeOfKind(hand)){
			p.winnings(3);
			return "Three of a Kind!";
		}
		
		else if(twoPairs(hand)){
			p.winnings(2);
			return "Two Pairs!";
		}
		
		else if(onePair(hand)){
			p.winnings(1);
			return "One Pair!";
		}
		
		else{
			return "You didn't score anything.";
		}
	}
	
	//check for one pair in hands
	private boolean onePair(ArrayList<Card> hand){
		boolean onePair = false;
		int pair = 0;
		
		for(int i = 0; i < 4; i++){
			if (hand.get(i).getRank() == hand.get(i+1).getRank()){
				pair += 1;
			}
		}
		
		if(pair != 2 && pair != 0){
			onePair = true;
		}
		
		return onePair;
	}

	//check for two pairs in hands
	private boolean twoPairs(ArrayList<Card> hand){
		boolean twoPairs = false;
		int pair = 0;
		
		for(int i = 0; i < 4; i++){
			if (hand.get(i).getRank() == hand.get(i+1).getRank()){
				pair += 1;
			}
		}
		
		if(pair == 2){
			twoPairs = true;
		}
		
		return twoPairs;
	}

	//check for three of a kind in hands
	private boolean threeOfKind(ArrayList<Card> hand){
		boolean threeOfKind = false;
		
		for(int i = 0; i < 3; i++){
			if (hand.get(i).getRank() == hand.get(i+1).getRank()){
				if (hand.get(i).getRank() == hand.get(i+2).getRank())
				threeOfKind = true;
			}
		}
		
		return threeOfKind;
	}

	//check for a straight in hands
	private boolean straight(ArrayList<Card> hand){
		boolean straight = false;
		int count = 0;
		
		for(int i = 0; i < 4; i++){
			if(hand.get(i).getRank() + 1 == hand.get(i+1).getRank()){
				count ++;
			}
		}
		
		if(count == 3){
			if(hand.get(0).getRank()==1 && hand.get(4).getRank()==13){
				count += 1;
			}
		}
		
		if(count == 4){
			straight = true;
		}
		
		return straight;
	}

	//check for a flush in hands
	private boolean flush(ArrayList<Card> hand){
		boolean flush = false;
		int count = 0;
		
		for(int i = 1; i < 5; i++){
			if(hand.get(i).getSuit() == hand.get(0).getSuit()){
				count ++;
			}
		}
		
		if(count == 4){
			flush = true;
		}
		
		return flush;
	}

	//check for a fullhouse in hands
	private boolean fullHouse(ArrayList<Card> hand){
		boolean fullHouse = false;
		
		if(onePair(hand) && threeOfKind(hand)){
			fullHouse = true;
		}
		
		return fullHouse;
	}
	
	//check for four of a kind in hands
	private boolean fourOfKind(ArrayList<Card> hand){
		boolean fourOfKind = false;
		int count = 0;
		
		if(hand.get(0).getRank()==hand.get(1).getRank()){
			for(int i = 1; i < 4; i++){
				if(hand.get(i).getRank() == hand.get(0).getRank()){
					count ++;
				}
			}
		}
		else{
			for(int j = 3; j < 5; j++){
				if(hand.get(j).getRank() == hand.get(2).getRank()){
					count ++;
				}
			}
		}
		
		if(count == 3){
			fourOfKind = true;
		}
		
		return fourOfKind;
	}

	//check for a straight flush in hands
	private boolean straightFlush(ArrayList<Card> hand){
		boolean straightFlush = false;
		
		if(straight(hand) && flush(hand)){
			straightFlush = true;
		}
		
		return straightFlush;
	}

	//check for a royal flush in hands
	private boolean royalFlush(ArrayList<Card> hand){
		boolean royalFlush = false;
		
		if(hand.get(0).getRank() == 1 && hand.get(1).getRank() == 10 &&
		   hand.get(2).getRank() == 11 && hand.get(3).getRank() == 12 &&
		   hand.get(4).getRank() == 13){
			royalFlush = true;
		}
		
		return royalFlush;
	}
}
