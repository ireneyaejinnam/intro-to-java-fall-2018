//
// @Name: Irene Nam
// @UNI: yn2334
// 
// This class provides methods for the Game class
// regarding the player's card and bankrolls.
// 
// 

import java.util.*;

public class Player {
	
		
	private ArrayList<Card> hand; // the player's cards
	//instance variables for bankroll and bet
	private double bankroll;
    private double bet;

	
	//initialize instance variables
	public Player(){		
	    hand = new ArrayList<Card>();
		this.bankroll = bankroll;
	}

	//sets bankroll from the parameter
	public void intialBankroll(double money){
		bankroll = money;
	}
	
	//add card to the hands from parameter
	public void addCard(Card c){
	    hand.add(c);
	}

	//remove card to the hands from parameter
	public void removeCard(Card c){
	    hand.remove(c);
	}
	
	//replace the cards from certain index with
	//a new card
	public void replaceCard (int index, Card c){
		hand.set(index-1, c);
	}
	
	//returns the hands
	public ArrayList<Card> getHand(){
		return hand;
	}
	
	//sets bets from the parameter
	public void bets(double amt){
		bet = amt;
	}

	//calculate how much the player wins and updates
	//the bankroll
	public void winnings(double odds){
		bankroll = bankroll + (bet * odds);
	}
	
	//returns the bankroll
	public double getBankroll(){
		return bankroll;
	}
	
	//subtract the amount of bets from the bankroll
	public void getBets(){
		bankroll = bankroll - bet;
	}
	
	//sort the hands
	public void sorting(){
		Collections.sort(hand);
	}
}


