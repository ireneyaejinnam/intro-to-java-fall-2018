//
// @Name: Irene Nam
// @UNI: yn2334
// 
// This class creates a deck of cards and shuffles it
// and deals it by removing the top card from deck.
// 

import java.util.Random;

public class Deck {
	
	//array for cards
	private Card[] cards;
	// the index of the top of the deck
	private int top = -1;
	//random for shuffling the cards
	private Random r = new Random();


	//create a new deck with 52 cards
	public Deck(){
		cards = new Card[52];
		int index = 0;
		int top = 0;
		
		//creating single card by using two for loops
		//one for ranks and one for suits
		for (int i = 0; i < 4; i++){
			for (int j = 0; j < 13; j++){
				Card singleCard = new Card(i, j);
				cards[index] = singleCard;
				index ++;
			}
		}
	}
	
	//shuffle the cards by randomizing the cards and
	//rearranging the deck.
	public void shuffle(){
		for (int i = 0; i < 52; i++){
			int newIndex = r.nextInt(52);
			Card temp = cards[i];
			cards[i] = cards[newIndex];
			cards[newIndex] = temp;
		}
	}
	
	//Deal the card by removing the top card in deck.
	public Card deal(){
		top += 1;
		return cards[top];
	}
	
	//reset the top card index so the deck doesn't run out
	//even after dealing more than 52 cards.
	public void resetTop(){
		top = 0;
	}

}
