Video Poker

Irene Nam (yn2334)


1. Card.java

	This class creates a Card object. Within the class, there are instance variables for suits, ranks, suit symbols, and rank names. First, we instantiate the suit and rank instance variables as integers 1-4 and 1-13. Then, we create a compareTo method to compare the rank value of the cards to use it when we sort the deck of cards. After that, we create a method toString() that prints the card in a pretty card format. The last two methods: getRank() and getSuit() simply returns the rank and suit of the card in integer values.

2. Deck.java

	This class creates a deck of cards, shuffles it, and deals it by removing the top card from the deck. First, we create instance variables for the array of cards, the index of the top of the deck, and random for shuffling the cards. Then, we instantiate the instance variables, then create cards by using two for loops. Then in the shuffle() method, shuffle the cards by randomizing the cards and rearranging the deck. The deal() method should deal the card by removing the top card in deck, and the resetTop() method should reset the top card index so we don’t run out of the deck.

3. Player.java

	This class provides methods for the Game class regarding the player’s card and bankrolls. There are instance variables for the player’s cards, bankroll, and bet. We initialize the instance variables first. initialBankroll method sets bankroll from the given parameter, addCard method adds card to the hands from parameter, removeCard removes a card to the hands from the parameter, replaceCard method replace the cards from certain index with a new card, getHand method returns the hands, bets method sets bet from the parameter, winnings method calculates how much the player wins and updates the bankroll, getBankroll method returns the bankroll, getBets method subtracts the amount of bets from the bankroll, and sorting method sorts the hand.

4. Game.java

	This class runs the game of video poker.
	There are instance variables for player, deck, a string array for suits and ranks, and a boolean handTest to test if testHand constructor is being used.
	Game constructor with parameters testHand helps test the code by plugging in the exact playing cards to check the code. From the array, we divide up the elements into suit and rank values and adds it as a new card in the hands. The constructor without an argument plays a normal game from the random deck.
	Play method has all the functions of the game. If using the testHand constructor, it will receive the cards from the written list instead of receiving from the deck. If not using the testHand, the player will continue the game. First, it will show the total balance using getBankroll method in Player. Then, check if token number is valid. If invalid token number, ask for a valid one. If valid token number, stop asking for the token number and go through the bets method to calculate new balance after the new bet. Print the current total balance. Shuffle the card, reset the top card index after every play so the cards never run out. Print out the cards in hand, let the player choose cards to switch, receive the player choice. Unless they want to switch anything, switch the cards at given index, leaving the ones that the player wants to leave. Display the new set of cards, score the hand by calculating the payout, and print out the new current balance. Ask if the player wants to play again. If yes, continue the play, remove all old cards from the deck and if not, finish the game.
	The checkHand method takes an ArrayList of cards as inputs, determines what evaluates to, returns it as a String. Sort the hands, test from the biggest payout.
	The onePair, twoPairs, threeOfKind, straight, flush, fullHouse, fourOfKind, straightFlush, and royalFlush methods will check for each payout and return the payout as a boolean.