//
// @Name: Irene Nam
// @UNI: yn2334
// 
// This class makes the cards, compares them, and makes it printable.
// 

public class Card implements Comparable<Card>{
	
	private int suit; // use integers 1-4 to encode the suit
	private int rank; // use integers 1-13 to encode the rank
	//symbol sign that will print for the game
	private String[] suitSymbols = {"♣", "♦", "♥", "♠"};
	//rank sign that will print for the game
	private String[] rankNames = {"A", "2", "3", "4", "5", "6", "7", "8", 
								  "9", "10", "J", "Q", "K"};
	
	
	//creating a card with suit s and rank r
	public Card(int s, int r){
		suit = s;
		rank = r;
	}
	
	//Compare the rank value of the cards to use it in
	//collections.sort to sort the card to check payouts
	public int compareTo(Card c){
		int compare = 0;
		
		if (this.getRank() > c.getRank()){
			compare = 1;
		}
		else if (this.getRank() < c.getRank()){
			compare = -1;
		}
		else if (this.getRank() == c.getRank()){
			if (this.getSuit() > c.getSuit()){
				compare = 1;
			}
			else if (this.getSuit() < c.getSuit()){
				compare = -1;
			}
		}
		
		return compare;
	}
	
	//method to print the cards in a pretty way for the users
	public String toString(){
		String cardName = rankNames[rank] + suitSymbols[suit];
		return cardName;
	}
	
	//returns the rank in int between 1-13
	public int getRank(){
		return rank;
	}
	
	//returns the suit in int between 1-4
	public int getSuit(){
		return suit;
	}
	
}
