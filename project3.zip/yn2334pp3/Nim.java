/*****************************************
 * Test class for Nim game
 * 
 * @author Cannon
 
 ****************************************/ 

public class Nim{
	
    public static void main(String[] args){
        
        System.out.println("Welcome to Nim death match!");
        Game g = new Game();
        g.play();
        
        System.out.println("Thanks for playing!");
    }
	
	
}
