/*****************************************
 * A template for a computer Nim player
 * 
 * @author: Irene Nam
 * @date 3/5/2018
 * 
 * 
 ****************************************/ 

public class Computer{
    
	//difficulty of game: 0 for stupid 1 for smart
	private int level; //smart or stupid
	//computer's number of marbles removed
    private int choice = -1;
    
	//constructor for instance variables
	//explicit parameter m for mode number
    public Computer(int mode){
        level = mode;
    }
    
    //move of computer depending on the mode
	public void move(int marblesLeft){
    
        if (level == 0 || marblesLeft == 3 || marblesLeft == 7 || marblesLeft == 15 
			|| marblesLeft == 31 || marblesLeft == 63) {
			choice = (int) (Math.random() * (marblesLeft / 2)) + 1;
		}
		else {
			if (marblesLeft > 63) {
				choice = marblesLeft - 63;
			}
			else if (marblesLeft > 31) {
				choice = marblesLeft - 31;
			}
			else if (marblesLeft >15) {
				choice = marblesLeft - 15;
			}
			else if (marblesLeft > 7) {
				choice = marblesLeft - 7;
			}
			else if (marblesLeft > 3) {
				choice = marblesLeft - 3;
			}
			else {
				choice = marblesLeft -1;
			}
		}  
    }
    
    //returns computer choice
    public int getChoice(){
        return choice;
    }
    
    
}
