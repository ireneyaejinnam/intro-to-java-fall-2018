/*****************************************
 * A template for a Human Nim player
 * 
 * @author: Irene Nam
 * @date 3/5/2018
 * 
 * 
 ****************************************/ 
import java.util.Scanner;

public class Human{
   
	//choice: number of marbles a human player takes
    private int choice;
	//asking for human player input
    private Scanner input;
    
	//constructor to initialize instance variables
    public Human(){
        input=new Scanner(System.in);
        choice = -1;
    }
    
	//determines how many marbles to move from the pile
    public void move(){
    
        System.out.println("How many marbles do you want to remove from the pile?");
		choice = input.nextInt();
        
    }
    
    //returns human choice
    public int getChoice(){
        return choice;
    }
    
    
}
