/*****************************************
 * A template for a Nim game
 * 
 * @author: Irene Nam
 * @date 3/5/2018
 * 
 * 
 ****************************************/ 


public class Game{
    
	//instance variables
	private Human humanPlay;
	private Computer computerPlay;
	private boolean playContinue;
	private int pileSize = 0;
	private int turn = -1;
	private int level = -1;

    //constructor initializes instance variables
    public Game(){
		humanPlay = new Human();
		//computer will play according to the difficulty level, received
		//by the explicit parameter in the Computer class.
		//decide how the computer will play
		level = (int) (Math.random()*2);
		computerPlay = new Computer(level);
		playContinue = true;
    }
    
	//play method starts the game
    public void play(){
		
		//randomize pile size between 10-100
        pileSize = (int) (Math.random() * 91) + 10;
		//randomize turn by either 0 for human and 1 for computer
		turn = (int) (Math.random()*2);
		//print initial pile size
		System.out.println("The size of the pile is " + pileSize + "marbles.");
		//depending on the turn, decide who plays first
		if (turn == 0) {
			System.out.println("Your turn.");
		}
		else if (turn == 1) {
			System.out.println("Computer's turn.");
		}
		
		//while loop to ensure that you stop playing once the size of pile
		//is less than or equal to 1
		while (playContinue) {
			//if human plays
			if (turn == 0) {
				//this method will take in human's input
				humanPlay.move();
				//receive human's choice
				int humanMarblesRemoved = humanPlay.getChoice();
				//calculates the new pile size if it's a valid move
				if (humanMarblesRemoved <= (pileSize / 2)) {
					pileSize = pileSize - humanMarblesRemoved;
					//switch turns
					turn = 1;
				}
				//re-receive input if the move isn't valid
				else {
					System.out.println("Please remove less than half of the marbles in the pile.");
				}
			}
			//if computer plays
			else if (turn == 1) {
				//computer will make a valid move according to pileSize
				computerPlay.move(pileSize);
				//receive computer choice
				int computerMarblesRemoved = computerPlay.getChoice();
				//calculates the new pile size
				pileSize = pileSize - computerMarblesRemoved;
				//returns how many removed from the pile
				//and how many is left in the pile
				System.out.println("The computer removed " + computerMarblesRemoved + " marbles from the pile.");
				System.out.println("There are " + pileSize + " marbles left in the pile.");
				//switch turns
				turn = 0;
			}
			
			//if the pile size is equal to 1, there is
			//a clear winner for the game, so have to break from the
			//while loop above.
			if (pileSize == 1) {
				//change boolean so it will exit the while loop
				//for the next iteration
				playContinue = false;
				//if the next turn is assigned to be human, computer won
				if (turn == 0) {
					System.out.println("Computer Won!");
				}
				//if the next turn is assigned to be computer, human won
				else if (turn ==1) {
					System.out.println("You Won!");
				}
			}
		}
    }
}
