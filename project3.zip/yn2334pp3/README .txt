*
*
* Name: Irene Nam
* UNI: yn2334
* Date Due: 3/5/2018
*
*
----------------------------------------------------------------------------------------------------

Problem 1 (CreditCard.java):

First, I created instance variables for the integer for error code and the string card number, since those are the final variables we want to return at the end. 

I then made a constructor to initialize the instance variables, and set the explicit parameter to the string of the card number we get for our input. 

Then, I made a check() method to check for 6 different requirements for a valid card number. 
First, I made sure that the string of the card number that I'm dealing with is only a set of numbers, not a set with dashes or spaces (given the person enters all 16 digits of the card).
Then, I converted all the string and character values of the digits needed according to the 6 tests below. For the sum of all digits, sum of first four digits, and sum of last four digits, I used a for loop to loop through the range of those digits and sum them up. These are how I satisfied the requirements:
1) The first digit must be a 4
	I simply compared the first element of the string and tested if it was equal to the character '4'. If not, the error code will be set to 1.
2) The fourth digit must be one greater than the fifth digit
	I got the fourth and fifth element of the string as a character, then got the numeric values of the numbers in character form. Then, I made an equation comparing if the fourth digit was equal to the fifth digit plus one. If not, the error code will be set to 2.
3) The product of the first, fifth, and ninth digits must be 24
	Similar to the 2nd one, I got each element of the string as a character, then got the numeric values of them. I made an equation multiplying these elements equaling to 24. If not, the error code will be set to 3.
4) The sum of all digits must be evenly divisible by 4.
	First, I set an integer called sumDigits to zero. Then, by using the for loop until the last number of the card number, I figured out the sum of the whole card number (numeric value figured out the same way, from string to char to int). If the sum wasn't divisible by 4, the error code will be set to 4.
5) The sum of the first four digits must be one less than the sum of the last four digits
	First, I set two integer values (sumFirstFourDigits, sumLastFourDigits) to zero. Then, by using a similar method of for loop with ranges according to each value, I figured out the sum of each sour digits. If the sum of first four digits wasn't one less than the sum of last four digits, the error code will be set to 5.
6) If you treat the first two digits as a two-digit number and the seventh and eight digits also as a two-digit number, the sum of those two numbers will equal to 100.
	First, to get two digits instead of 1, I used the substring method to get the two digit numbers of each. Then, to convert the string to an int, I used parseInt, and if the sum wasn't equal to zero, the error code will be set to 6.

Else if statements were used to return the first error code value of the violated method number. It will also guarantee more efficient coding since, once it violates at least one method, it will stop testing and return that the card number is invalid and the error code violated.

Then, I made a boolean isValid() method, which is an accessor method that returns the value of the boolean that evaluates a valid card number (true for error code 0 and false for any other error codes).

Then, I made an int getErrorCode() method, which is an accessor method that returns the violated error code. If there are most than one violations, the system will return the last error code number it has violated.

This will be used in the CreditCardTester.java to test for valid card numbers. If valid, it will simply return that it's valid. If not, it will return that it's invalid and the error code it has violated.

----------------------------------------------------------------------------------------------------

Problem 2 (Nim game):

Human.java:

This class is a template for a human nim player. It will have two instance variables (initialized by a constructor), choice and scanner input to receive the player move from the player and store it in "choice". The getChoice() method will return the human choice.


Computer.java:

This class is a template for a computer sim player. There are instance variables for the difficulty of the play and choice of the computer. The constructor for instance variables will take in an explicit parameter of the level of play. Then, the move(int marblesLeft) method will take in the number of marbles left as the explicit parameter. If the number of marbles left is already 2^n-1 or if the difficulty level is 1, it will simply remove a valid number (equal to or less than half the pile). If not, depending on the size of the pile, it will remove number of marbles that will make the pile size 2^n-1. The if statement will begin from the larger number and have else if statements to avoid going through the wrong size pile (smaller than the criteria it should take in). This way, we can manage the computer's play by both difficulty level and size of the pile. Same as the getChoice() method in human class, it will return the computer choice.

Game.java:

This class will have six instance variables. There will be two for each new class of player, a boolean to evaluate if the play is over or not, and three integer variables for difficulty level, pile size, and turn.
The constructor will initialize the instance variables. The computerPlay variable will take in "level" as its explicit parameter, and playContinue boolean will be set as true to begin with.
Then, the play() method will start the game and take the difficulty level by receiving a random number 0 or 1 for stupid and smart play. Then, the pile size will be randomized for the level of difficulty for the computer's play, randomized for any integers between 10-100 and the turn will be randomized by either 0 or 1 (0 for human playing first, and 1 for computer playing first). Then, the computer will print out the initial number of marbles in the pile, and decides who plays first depending on the random turn number. If turn is 0, it will print that human will play first, and if the turn is 1, it will print that the computer will play first. The play will begin accordingly.
Then, I will construct a while loop to ensure that the play will finish if the pile size is equal to 1. While the boolean is true, if it's human's turn, move() method ask and take in the human's input from the Human class. getChoice() method from the Human class will determine the marbles being removed from the pile. Then, if it's a valid move (less than half the pile size), it will calculate the new pile size. If not, it will direct the player to re-enter a new valid move. Then, the turn will switch to the computer's. If it's the computer's turn, move(pileSize) from the Computer class will determine the computer's play depending on the size of the marble pile. Since the computer will only make valid moves, it will immediately return and print the number of marbles removed, and calculate and print the number of marbles left in the pile. Then, the turn will switch to the player's.
If the pile size is less than or equal to 1, it will exit the while loop by setting the playContinue boolean to false. To determine the winner, if there is one marble left in the pile and the next turn is the player, the computer will be the winner. In the other way, human player will be the winner. It will print the message accordingly.

Nim.java:

This class will be the test class for the game. It will begin a new game by calling the play method in the Game class, then end the game if it's over.