/*
*
* @author: Irene Nam
* @date 3/5/2018
*
* This class checks for valid credit card numbers
* and checks through the CreditCardTester test class
*
*/

public class CreditCard
{

	//instance variables
	private int errorCode = 0;
	private String cardNumber;
	 
	//constructor for instance variables
	public CreditCard(String number) {
		cardNumber = number;
	}
	
	public void check() {
		//check if credit card is valid of not
		//validity should be stroed in an instance variable of type boolean
		cardNumber = cardNumber.replaceAll("\\W","");

		//variables to use

		//get character values of single digits (to convert into integers
		//by using the getNumericValue method.)
		char firstDigit = cardNumber.charAt(0);
		char fourthDigit = cardNumber.charAt(3);
		char fifthDigit = cardNumber.charAt(4);
		char ninthDigit = cardNumber.charAt(8);

		//set intial sum to zero to go through for loop
		int sumDigits = 0;
		int sumFirstFourDigits = 0;
		int sumLastFourDigits = 0;
		String firstAndSecond = cardNumber.substring(0,2);
		String seventhAndEigth = cardNumber.substring(6,8);
		

		//sum of all digits
		for (int i = 0; i<cardNumber.length(); i++) {
			sumDigits += Character.getNumericValue(cardNumber.charAt(i));
		}
		//sum of first four digits
		for (int i = 0; i<4; i++) {
			sumFirstFourDigits += Character.getNumericValue(cardNumber.charAt(i));
		}
		//sum of last four digits
		for (int i = 8; i<cardNumber.length(); i++) {
			sumLastFourDigits += Character.getNumericValue(cardNumber.charAt(i));
		}


		//1. The first digit must be a 4
		if (firstDigit != '4') {
			errorCode = 1;
		}
		
		//2. The fourth digit must be one greater than the fifth digit
		else if (Character.getNumericValue(fourthDigit) != 
		Character.getNumericValue(fifthDigit) + 1) { 
			errorCode = 2;
		}
		
		//3. The product of the first, fifth, and ninth digits must be 24
		else if ((Character.getNumericValue(firstDigit) * 
		Character.getNumericValue(fifthDigit) *Character.getNumericValue(ninthDigit))
		!= 24) {
			errorCode = 3;
		}
		
		//4. The sum of all digits must be evenly divisible by 4
		else if (sumDigits % 4 != 0) {
			errorCode = 4;
		}
		
		//5. The sum of the first four digits must be one less than
		//the sum of the last four digits
		else if (sumFirstFourDigits != sumLastFourDigits - 1) {
			errorCode = 5;
		}
		
		//6. If you treat the first two digits as a two-digit number,
		//and the seventh and eight also as a two digit number,
		//their sum must be 100.
		else if (Integer.parseInt(firstAndSecond) + 
		Integer.parseInt(seventhAndEigth) != 100) {
			errorCode = 6;
		}
	}
	
	public boolean isValid() {
		//Accessor method that returns the value of boolean
		if (errorCode == 0) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public int getErrorCode() {
		//Accessor method that returns the value of the variable errorCode
		return errorCode;
	}
}